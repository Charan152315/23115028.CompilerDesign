


# Custom Expression Parser

This project is a simple compiler front-end using *Flex (Lexer)* and *Bison (Parser)* to parse expressions of the form:

a = b + c * d + e;

csharp

It converts this into a *custom instruction format*, such as:

custom_addmuladd a, b, c, d, e

yaml
Copy
Edit

---



- parser.y – Bison grammar definition
- lexer.l – Flex lexical analyzer
- Makefile (optional) – Automate build steps
- parser – Compiled executable after build

---

## 🛠 Build Instructions

Make sure you have flex, bison, and gcc installed.

### Step-by-Step:

```bash
bison -d parser.y         # Generates parser.tab.c and parser.tab.h
flex lexer.l              # Generates lex.yy.c
gcc -o parser parser.tab.c lex.yy.c -lfl
Run the Parser:
bash

./parser
Enter an expression like:

ini
Copy
Edit
a = b + c * d + e;
Output will be:

less

Custom instruction: custom_addmuladd a, b, c, d, e
📄 Example Grammar
The Bison grammar breaks the expression down as:

nginx
Copy
Edit
stmt → id1 = id2 + id3 * id4 + id5 ;
And translates it into a single instruction using snprintf():

c
Copy
Edit
custom_addmuladd id1, id2, id3, id4, id5
💡 Notes
Only supports identifiers, no numeric constants yet.

Whitespace and semicolons are handled by the lexer.

Expressions must match the pattern a = b + c * d + e;.

🧩 Future Improvements
Add support for numeric literals

Handle nested parentheses

Generate assembly-style or bytecode output

Add error recovery and better syntax checks

🧑‍💻 Author
Made with Flex and Bison for educational purposes. Happy parsing!

yaml
Copy
Edit

---

Let me know if you'd like a Makefile or want to support more complex expressions in the future!


Github(https://github.com/Charan152315/23115028.CompilerDesign)